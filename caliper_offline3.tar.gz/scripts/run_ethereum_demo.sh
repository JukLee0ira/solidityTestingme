#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: 未找到 node。离线包不包含 node，请先安装 Node.js。"
  exit 1
fi
if ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: 未找到 npm。请安装 npm。"
  exit 1
fi

CFG="demo/ethereum/ethereum/networkconfig.json"

echo "[eth-demo] 使用配置: ${CFG}"
echo "[eth-demo] 重要：caliper-ethereum 禁止 http(s)，必须使用 ws:// 端点（geth 需要开启 --ws）"
echo "[eth-demo] 请先编辑 ${CFG}，填入："
echo "          - ethereum.url"
echo "          - contractDeployerAddress / contractDeployerAddressPrivateKey"
echo "          - fromAddress / fromAddressPrivateKey"

export NO_UPDATE_NOTIFIER=1

npx --no-install caliper launch manager \
  --caliper-workspace "${ROOT_DIR}" \
  --caliper-benchconfig "demo/ethereum/benchconfig.yaml" \
  --caliper-networkconfig "${CFG}" \
  --caliper-report-path "demo/ethereum/ethereum/report.html"

echo "[eth-demo] OK: demo/ethereum/ethereum/report.html 已生成"


