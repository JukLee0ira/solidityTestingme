/*
 * 离线 demo ConnectorFactory：
 * - 被 Caliper CLI 通过 networkconfig 的 `caliper.blockchain` 以“本地路径模块”方式加载
 * - 必须导出名为 `ConnectorFactory` 的函数（参见 Constants.Factories.Connector）
 */
'use strict';

const DemoConnector = require('./demo-connector');

/**
 * @param {number} workerIndex worker 的 0-based index；manager 进程会传 -1
 * @returns {Promise<import('@hyperledger/caliper-core').ConnectorBase>}
 */
async function connectorFactory(workerIndex) {
    return new DemoConnector(workerIndex, 'demo');
}

module.exports.ConnectorFactory = connectorFactory;


