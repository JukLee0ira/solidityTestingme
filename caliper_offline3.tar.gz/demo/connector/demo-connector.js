/*
 * 纯本地 SUT 连接器：
 * - 不依赖 Fabric/Ethereum/Docker
 * - 不会在运行时触发 npm install / bind
 * - 用于验证离线包“可启动+可跑完一轮”
 */
'use strict';

const { ConnectorBase, TxStatus, CaliperUtils } = require('@hyperledger/caliper-core');

const logger = CaliperUtils.getLogger('demo-connector');

class DemoConnector extends ConnectorBase {
    /**
     * @param {number} workerIndex
     * @param {string} bcType
     */
    constructor(workerIndex, bcType) {
        super(workerIndex, bcType);
        this._counter = 0;
        this._inited = false;
    }

    /**
     * 初始化（Caliper manager 进程会调用一次；worker 进程不一定调用）
     * @param {boolean} workerInit
     */
    async init(workerInit = false) {
        this._inited = true;
        logger.info(`init() called, workerIndex=${this.workerIndex}, workerInit=${workerInit}`);
    }

    async installSmartContract() {
        // demo：不需要部署合约
        logger.info('installSmartContract() noop');
    }

    async getContext(roundIndex, args) {
        return {
            roundIndex,
            workerIndex: this.workerIndex,
            args: args || {},
            inited: this._inited
        };
    }

    async releaseContext() {
        // demo：无资源需要释放
    }

    /**
     * 发送单笔请求（ConnectorBase 的 sendRequests() 会处理批量 & 事件）
     * @param {object} request
     * @returns {Promise<TxStatus>}
     */
    async _sendSingleRequest(request) {
        const id = request && (request.txId || request.id) ? (request.txId || request.id) : `${this.workerIndex}-${++this._counter}`;
        const status = new TxStatus(id);

        // 给 report 一个可用的结果对象
        status.SetResult({
            ok: true,
            echo: request && request.payload ? { bytes: request.payloadBytes || undefined } : undefined
        });
        status.SetVerification(true);
        status.SetStatusSuccess();
        return status;
    }
}

module.exports = DemoConnector;


