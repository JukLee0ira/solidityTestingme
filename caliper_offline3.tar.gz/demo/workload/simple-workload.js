/*
 * 最小 workload：
 * - 生成固定大小 payload
 * - 调用 sutAdapter.sendRequests()，由 demo connector 直接返回 success
 */
'use strict';

const crypto = require('crypto');
const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class SimpleWorkload extends WorkloadModuleBase {
    constructor() {
        super();
        this._txIndex = 0;
        this._payloadBytes = 16;
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        this._payloadBytes = (roundArguments && roundArguments.payloadBytes) ? Number(roundArguments.payloadBytes) : 16;
        if (!Number.isFinite(this._payloadBytes) || this._payloadBytes < 0) {
            this._payloadBytes = 16;
        }
    }

    async submitTransaction() {
        const txId = `w${this.workerIndex}-r${this.roundIndex}-${++this._txIndex}`;
        const payload = crypto.randomBytes(this._payloadBytes).toString('hex');

        const req = {
            txId,
            payload,
            payloadBytes: this._payloadBytes
        };

        await this.sutAdapter.sendRequests(req);
    }
}

function createWorkloadModule() {
    return new SimpleWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;


