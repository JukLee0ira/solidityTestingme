/*
 * Ethereum/Besu demo workload：
 * - 调用 caliper-ethereum 连接器期望的 request 格式：{contract, verb, args, readOnly?}
 * - 每次提交调用 SimpleStorage.set(uint256)
 */
'use strict';

const { WorkloadModuleBase } = require('@hyperledger/caliper-core');

class StorageWorkload extends WorkloadModuleBase {
    constructor() {
        super();
        this._txIndex = 0;
        this._contractKey = 'simpleStorage';
    }

    async initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext) {
        await super.initializeWorkloadModule(workerIndex, totalWorkers, roundIndex, roundArguments, sutAdapter, sutContext);
        if (roundArguments && typeof roundArguments.contract === 'string' && roundArguments.contract.trim()) {
            this._contractKey = roundArguments.contract.trim();
        }
    }

    async submitTransaction() {
        const v = ++this._txIndex;
        const req = {
            contract: this._contractKey,
            verb: 'set',
            args: [v],
            readOnly: false
        };

        await this.sutAdapter.sendRequests(req);
    }
}

function createWorkloadModule() {
    return new StorageWorkload();
}

module.exports.createWorkloadModule = createWorkloadModule;


