## 目标

把 Hyperledger Caliper（本仓库固定使用 `@hyperledger/caliper-cli@0.6.0`）的 **全部运行依赖** 在“有网机器”上准备好，并打包成 `tar.gz`，确保在另一台 **离线机器** 上：

- **不需要 `npm install`**
- **运行时不触发任何 npm 下载**
- 带一个最小 demo 可验证可启动（生成 `report.html`）

> 注意：离线包 **不包含 Node.js**（按你的要求控制体积），离线机器需要自行安装 Node/npm。

---

## 在有网机器上准备（本机）

### 1) 安装依赖（只需一次）

在仓库根目录：

```bash
npm ci --omit=dev
```

### 2) 运行 demo 验证（推荐）

```bash
bash scripts/run_demo.sh
```

成功标志：生成 `demo/report.html`。

### 3) 打包离线 tar.gz

```bash
bash scripts/make_offline_tar.sh
```

会在仓库根目录生成 `caliper_offline_bundle_*.tar.gz`。

---

## 在离线机器上使用

### 1) 前置条件（离线机）

- 安装 Node.js（建议 v18 LTS，且与打包机器同架构/系统更稳妥）
- 安装 npm（通常随 Node 一起）

### 2) 解压

```bash
tar -xzf caliper_offline_bundle_*.tar.gz
cd caliper_offline
```

> 目录名取决于你解压位置；如果你想固定名字，可以把解压目录改名为 `caliper_offline`。

### 3) 运行 demo（离线验证）

```bash
bash scripts/run_demo.sh
```

成功标志：生成 `demo/report.html`，且执行过程中不会触发 `npm install`/下载。

---

## 离线运行的关键点（为什么不会运行期下载）

- demo 的 `demo/networkconfig.yaml` 把 `caliper.blockchain` 指向本地模块：`./demo/connector/demo-connector-factory.js`
- `scripts/run_demo.sh` 使用 `npx --no-install`，强制只用本地 `node_modules`，不允许 npx 联网安装
- 只要 **不要传 `--caliper-bind-sut`**（也不要设置环境变量 `CALIPER_BIND_SUT`），Caliper 就不会执行 `npm install` 的 bind 流程


