#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT_DIR}"

VERSION="$(node -p "require('./package.json').dependencies['@hyperledger/caliper-cli'] || 'unknown'")"
TS="$(date +%Y%m%d_%H%M%S)"
OUT_NAME="caliper_offline_bundle_${VERSION}_${TS}.tar.gz"

if [[ ! -d "${ROOT_DIR}/node_modules" ]]; then
  echo "ERROR: 未发现 node_modules。请先在有网络的机器上执行: npm ci --omit=dev"
  exit 1
fi

# 给用户一个体积/内容都可控的 tar：
# - 不包含 node（二进制不打包）
# - 排除 git 与常见无关目录
# - 保留 node_modules（离线机无需 npm install）
echo "[pack] 输出文件: ${ROOT_DIR}/${OUT_NAME}"

tar -czf "${OUT_NAME}" \
  --exclude-vcs \
  --exclude="./demo/report.html" \
  --exclude="./node_modules/**/test/**" \
  --exclude="./node_modules/**/tests/**" \
  --exclude="./node_modules/**/docs/**" \
  --exclude="./node_modules/**/doc/**" \
  --exclude="./node_modules/**/example/**" \
  --exclude="./node_modules/**/examples/**" \
  --exclude="./node_modules/**/coverage/**" \
  --exclude="./node_modules/**/.github/**" \
  --exclude="./node_modules/**/.git/**" \
  --exclude="./node_modules/**/CHANGELOG*" \
  --exclude="./node_modules/**/README*" \
  --exclude="./node_modules/**/readme*" \
  --exclude="./node_modules/**/LICENSE*" \
  package.json package-lock.json node_modules demo scripts README_OFFLINE.md

echo "[pack] 完成: ${OUT_NAME}"
echo "[pack] 建议先本机验证: bash scripts/run_demo.sh"


