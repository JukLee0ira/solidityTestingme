#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

cd "${ROOT_DIR}"

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: 未找到 node。离线包不包含 node，请先在机器上安装 Node.js (建议 v18 LTS)。"
  exit 1
fi

if ! command -v npm >/dev/null 2>&1; then
  echo "ERROR: 未找到 npm。请安装 npm（通常随 Node.js 一起安装）。"
  exit 1
fi

# 强制 npx 不联网/不安装：只使用本地 node_modules/.bin 中的 caliper
export NO_UPDATE_NOTIFIER=1

echo "[demo] workspace=${ROOT_DIR}"
echo "[demo] running: npx --no-install caliper launch manager ..."

npx --no-install caliper launch manager \
  --caliper-workspace "${ROOT_DIR}" \
  --caliper-benchconfig "demo/benchconfig.yaml" \
  --caliper-networkconfig "demo/networkconfig.yaml" \
  --caliper-report-path "demo/report.html"

echo "[demo] OK: demo/report.html 已生成"


